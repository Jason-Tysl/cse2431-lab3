# lab3

Name: Jason Tysl
Date: 10/27/2020
Class: CSE2431 - 11:10
Run make all, creating mysh, so use ./mysh to run the program.
